<?php

namespace Sensio\Bundle\FrameworkExtraBundle\Tests\Templating\Fixture\BarBundle\Controller;

class BarController
{
}
