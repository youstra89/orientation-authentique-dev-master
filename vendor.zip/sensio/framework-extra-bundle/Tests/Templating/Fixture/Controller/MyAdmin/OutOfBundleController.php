<?php

namespace Sensio\Bundle\FrameworkExtraBundle\Tests\Templating\Fixture\Controller\MyAdmin;

class OutOfBundleController
{
}
