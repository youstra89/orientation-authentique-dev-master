---
title: Stability
---

This is a list of supported versions, with their expected release/support time-frames:

# 2.0.x

 * Release date: 2016-01-30
 * Bug fixes: till 2017-12-31
 * Security fixes: till 2018-12-31

# 1.0.x

 * Release date: 2014-12-12
 * Bug fixes: till 2015-12-11
 * Security fixes: till 2016-12-11

# 0.5.x

 * Release date: 2013-12-01
 * Bug fixes: till 2015-03-11
 * Security fixes: till 2015-12-11
