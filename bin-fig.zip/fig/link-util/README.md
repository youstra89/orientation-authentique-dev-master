PSR Http Link Utilities
=======================

This repository includes common utilities to assist with implementing [PSR-13](http://www.php-fig.org/psr/psr-13/).

Note that it is not intended as a complete PSR-13 implementation, only a partial implementation
to make writing other implementations easier. 
